package com.example.evolvo.data.models

data class HabitProgress(
    val habitId: String = "",
    val date: String = "",
    val isCompleted: Boolean = false,
    val currentValue: Int = 0,
    val completionTime: Long? = null
)

// Extension function to calculate progress percentage
fun HabitProgress.getProgressPercentage(targetValue: Int): Int {
    return if (targetValue > 0) {
        (currentValue.toDouble() / targetValue.toDouble() * 100).toInt()
    } else {
        0
    }
}