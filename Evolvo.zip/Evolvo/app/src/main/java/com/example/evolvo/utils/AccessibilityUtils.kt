package com.example.evolvo.utils

import android.content.Context
import android.view.View
import android.view.accessibility.AccessibilityEvent
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import com.example.evolvo.R

/**
 * Utility class for handling accessibility features
 */
object AccessibilityUtils {
    
    /**
     * Ensure a view meets minimum touch target size requirements (48dp)
     */
    fun ensureMinimumTouchTargetSize(view: View) {
        val minSize = view.context.resources.getDimension(R.dimen.min_touch_target_size).toInt()
        val width = view.width
        val height = view.height
        
        if (width < minSize || height < minSize) {
            val paddingX = if (width < minSize) (minSize - width) / 2 else 0
            val paddingY = if (height < minSize) (minSize - height) / 2 else 0
            view.setPadding(
                view.paddingLeft + paddingX,
                view.paddingTop + paddingY,
                view.paddingRight + paddingX,
                view.paddingBottom + paddingY
            )
        }
    }
    
    /**
     * Set accessibility focus on a view
     */
    fun setAccessibilityFocus(view: View) {
        view.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
    }
    
    /**
     * Add custom accessibility description to a view
     */
    fun setAccessibilityDescription(view: View, description: String) {
        ViewCompat.setAccessibilityDelegate(view, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(
                host: View,
                info: AccessibilityNodeInfoCompat
            ) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = description
            }
        })
    }
    
    /**
     * Check if accessibility services are enabled
     */
    fun isAccessibilityEnabled(context: Context): Boolean {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        return accessibilityManager.isEnabled
    }
    
    /**
     * Check if touch exploration is enabled (for screen readers)
     */
    fun isTouchExplorationEnabled(context: Context): Boolean {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        return accessibilityManager.isTouchExplorationEnabled
    }
}