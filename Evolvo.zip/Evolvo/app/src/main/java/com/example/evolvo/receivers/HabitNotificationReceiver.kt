package com.example.evolvo.receivers

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.evolvo.MainActivity
import com.example.evolvo.R
import com.example.evolvo.data.models.Habit
import com.example.evolvo.data.models.HabitProgress
import com.example.evolvo.data.repository.SharedPreferencesManager

/**
 * BroadcastReceiver for handling habit goal reached notifications
 */
class HabitNotificationReceiver : BroadcastReceiver() {
    
    companion object {
        private const val CHANNEL_ID = "habit_notifications"
        private const val NOTIFICATION_ID_BASE = 2000
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        val habitId = intent.getStringExtra("habit_id") ?: return
        val prefsManager = SharedPreferencesManager.getInstance(context)
        
        // Get the habit and its progress
        val habit = prefsManager.getHabits().find { it.id == habitId } ?: return
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val progress = prefsManager.getHabitProgressForDay(habitId, today)
        
        // Check if the habit goal has been reached
        if (progress != null && progress.currentValue >= habit.targetValue) {
            createNotificationChannel(context)
            sendHabitGoalReachedNotification(context, habit, progress)
        }
    }
    
    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = context.getString(R.string.channel_habit_name)
            val descriptionText = context.getString(R.string.channel_habit_description)
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun sendHabitGoalReachedNotification(context: Context, habit: Habit, progress: HabitProgress) {
        // Create intent to open the app when notification is tapped
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("open_habits", true)
            putExtra("habit_id", habit.id)
        }
        
        val pendingIntent: PendingIntent = PendingIntent.getActivity(
            context,
            habit.id.hashCode(), // Unique request code based on habit ID
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        // Get default alarm sound
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        
        // Build the notification
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_habits)
            .setContentTitle("Habit Goal Reached! 🎉")
            .setContentText("Congratulations! You've completed your daily goal for \"${habit.name}\".")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Great job! You've completed ${progress.currentValue} ${habit.unit} of \"${habit.name}\" today.")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 500, 250, 500)) // Vibrate pattern
            .build()
        
        // Show the notification
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_BASE + habit.id.hashCode(), notification)
    }
}