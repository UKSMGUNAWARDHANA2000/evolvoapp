package com.example.evolvo.data.models

import java.util.UUID

data class Habit(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val description: String = "",
    val targetValue: Int = 1,
    val unit: String = "times",
    val category: String = CATEGORY_PERSONAL,
    val frequency: String = "Daily",
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val CATEGORY_ALL = "All"
        const val CATEGORY_HEALTH = "Health"
        const val CATEGORY_PRODUCTIVITY = "Productivity"
        const val CATEGORY_WELLNESS = "Wellness"
        const val CATEGORY_PERSONAL = "Personal"
        
        val CATEGORIES = listOf(
            CATEGORY_ALL,
            CATEGORY_HEALTH,
            CATEGORY_PRODUCTIVITY,
            CATEGORY_WELLNESS,
            CATEGORY_PERSONAL
        )
    }
}