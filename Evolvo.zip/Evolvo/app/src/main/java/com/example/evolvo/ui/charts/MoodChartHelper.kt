package com.example.evolvo.ui.charts

import android.content.Context
import com.example.evolvo.R
import com.example.evolvo.data.models.MoodEntry
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import java.text.SimpleDateFormat
import java.util.*

/**
 * Helper class for creating mood trend charts with enhanced UI
 */
class MoodChartHelper(private val context: Context) {
    
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
    
    fun setupMoodTrendChart(chart: LineChart, moodEntries: List<MoodEntry>) {
        chart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            setDragEnabled(true)
            setScaleEnabled(true)
            setPinchZoom(false)
            setBackgroundColor(context.getColor(R.color.surface))
            setDrawGridBackground(true)
            // Fixed: Use correct property name for grid background color
            setGridBackgroundColor(context.getColor(R.color.background_light))
            
            // Configure X-axis
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(true)
                setGridColor(context.getColor(R.color.background_light))
                setGridLineWidth(1f)
                granularity = 1f
                labelCount = 7
                textColor = context.getColor(R.color.text_secondary)
                textSize = 12f
            }
            
            // Configure Y-axis to have 0 in the middle
            axisLeft.apply {
                axisMinimum = -2.5f
                axisMaximum = 2.5f
                setDrawGridLines(true)
                setGridColor(context.getColor(R.color.background_light))
                setGridLineWidth(1f)
                textColor = context.getColor(R.color.text_secondary)
                textSize = 12f
                setLabelCount(5, false)
            }
            
            axisRight.isEnabled = false
            
            // Configure legend
            legend.apply {
                isEnabled = false
            }
            
            // Set viewport to show all data
            setVisibleXRangeMaximum(7f)
        }
        
        // Process mood data for the last 7 days
        val chartData = prepareMoodData(moodEntries)
        
        if (chartData.isNotEmpty()) {
            val dataSet = LineDataSet(chartData, "Daily Mood")
            dataSet.color = context.getColor(R.color.primary)
            dataSet.setCircleColor(context.getColor(R.color.primary))
            dataSet.lineWidth = 3f
            dataSet.circleRadius = 6f
            dataSet.setDrawCircleHole(true)
            dataSet.circleHoleColor = context.getColor(R.color.on_primary)
            dataSet.circleHoleRadius = 2f
            dataSet.valueTextSize = 12f
            dataSet.valueTextColor = context.getColor(R.color.text_primary)
            dataSet.setDrawFilled(true)
            dataSet.fillColor = context.getColor(R.color.primary_light)
            dataSet.fillAlpha = 100
            dataSet.mode = LineDataSet.Mode.HORIZONTAL_BEZIER
            dataSet.setDrawValues(true)
            
            // Custom value formatter to show mood values
            dataSet.valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    // Convert back to mood scale (1-5)
                    val moodValue = value + 3
                    return String.format("%.1f", moodValue)
                }
            }
            
            val lineData = LineData(dataSet)
            chart.data = lineData
            
            // Set up X-axis labels
            val labels = getLast7DaysLabels()
            chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            
            // Animate the chart
            chart.animateY(1000)
            chart.invalidate() // Refresh chart
        } else {
            chart.clear()
            chart.invalidate()
        }
    }
    
    private fun prepareMoodData(moodEntries: List<MoodEntry>): List<Entry> {
        val calendar = Calendar.getInstance()
        val entries = mutableListOf<Entry>()
        
        // Get mood data for the last 7 days
        for (i in 6 downTo 0) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -i)
            val dateString = dateFormat.format(calendar.time)
            
            // Find moods for this day
            val dayMoods = moodEntries.filter { it.date == dateString }
            
            if (dayMoods.isNotEmpty()) {
                // Calculate average mood for the day and center around 0
                // Convert 1-5 scale to -2 to +2 scale (0 in middle)
                val averageMood = dayMoods.map { it.mood.value }.average().toFloat()
                val centeredMood = averageMood - 3f  // Shift from 1-5 to -2 to +2
                entries.add(Entry((6 - i).toFloat(), centeredMood))
            } else {
                // No mood entry for this day
                entries.add(Entry((6 - i).toFloat(), 0f)) // 0 for no data
            }
        }
        
        return entries
    }
    
    private fun getLast7DaysLabels(): List<String> {
        val calendar = Calendar.getInstance()
        val labels = mutableListOf<String>()
        
        for (i in 6 downTo 0) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -i)
            labels.add(dayFormat.format(calendar.time))
        }
        
        return labels
    }
}