package com.example.evolvo.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.evolvo.R
import com.example.evolvo.data.repository.SharedPreferencesManager
import com.example.evolvo.ui.auth.LoginActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

/**
 * Fragment for app settings and preferences
 */
class SettingsFragment : BaseFragment() {
    
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var tvAppVersion: TextView
    private lateinit var tvWaterGoal: TextView
    private lateinit var switchNotifications: MaterialSwitch
    private lateinit var btnEditProfile: MaterialButton
    private lateinit var btnTheme: MaterialButton
    private lateinit var btnDefaultScreen: MaterialButton
    private lateinit var btnEditWaterGoal: MaterialButton
    private lateinit var layoutAbout: View
    private lateinit var layoutResetData: View
    private lateinit var layoutLogout: View
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize components
        initializeViews(view)
        setupClickListeners()
        loadSettings()
        loadUserProfile()
    }
    
    private fun initializeViews(view: View) {
        prefsManager = SharedPreferencesManager.getInstance(requireContext())
        tvUserName = view.findViewById(R.id.tv_user_name)
        tvUserEmail = view.findViewById(R.id.tv_user_email)
        tvAppVersion = view.findViewById(R.id.tv_app_version)
        tvWaterGoal = view.findViewById(R.id.tv_water_goal)
        switchNotifications = view.findViewById(R.id.switch_notifications)
        btnEditProfile = view.findViewById(R.id.btn_edit_profile)
        btnTheme = view.findViewById(R.id.btn_theme)
        btnDefaultScreen = view.findViewById(R.id.btn_default_screen)
        btnEditWaterGoal = view.findViewById(R.id.btn_edit_water_goal)
        layoutAbout = view.findViewById(R.id.layout_about)
        layoutResetData = view.findViewById(R.id.layout_reset_data)
        layoutLogout = view.findViewById(R.id.layout_logout)
    }
    
    private fun setupClickListeners() {
        btnEditProfile.setOnClickListener {
            showEditProfileDialog()
        }
        
        btnTheme.setOnClickListener {
            showThemeSelectionDialog()
        }
        
        switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            updateNotificationSettings(isChecked)
        }
        
        btnDefaultScreen.setOnClickListener {
            showDefaultScreenSelectionDialog()
        }
        
        btnEditWaterGoal.setOnClickListener {
            showWaterGoalDialog()
        }
        
        layoutAbout.setOnClickListener {
            showAboutDialog()
        }
        
        layoutResetData.setOnClickListener {
            showResetDataConfirmation()
        }
        
        layoutLogout.setOnClickListener {
            showLogoutConfirmation()
        }
    }
    
    private fun loadSettings() {
        val hydrationSettings = prefsManager.getHydrationSettings()
        switchNotifications.isChecked = hydrationSettings.reminderEnabled
        tvWaterGoal.text = "${hydrationSettings.dailyGoalMl} ml"
        tvAppVersion.text = "1.0.0" // In a real app, this would come from BuildConfig
    }
    
    private fun loadUserProfile() {
        // Load user profile information
        val userName = prefsManager.getUserName() ?: "User"
        val userEmail = "user@example.com" // This would come from actual user data
        
        tvUserName.text = userName
        tvUserEmail.text = userEmail
    }
    
    private fun updateNotificationSettings(enabled: Boolean) {
        val currentSettings = prefsManager.getHydrationSettings()
        val newSettings = currentSettings.copy(reminderEnabled = enabled)
        prefsManager.saveHydrationSettings(newSettings)
        
        if (enabled) {
            // Schedule the hydration alarm
            com.example.evolvo.receivers.HydrationAlarmScheduler.scheduleRecurringAlarm(requireContext(), newSettings)
            android.widget.Toast.makeText(
                requireContext(),
                "Notifications enabled",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        } else {
            // Disable notifications
            com.example.evolvo.receivers.HydrationAlarmScheduler.cancelAlarm(requireContext())
            android.widget.Toast.makeText(
                requireContext(),
                "Notifications disabled",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }
    
    private fun showEditProfileDialog() {
        android.widget.Toast.makeText(
            requireContext(),
            "Profile editing feature coming soon",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
    
    private fun showThemeSelectionDialog() {
        val themes = arrayOf("Light", "Dark", "System")
        val currentTheme = "System" // In a real app, this would come from settings
        val selectedIndex = themes.indexOf(currentTheme)
        
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select Theme")
            .setSingleChoiceItems(themes, selectedIndex) { dialog, which ->
                val selectedTheme = themes[which]
                // In a real app, you would save this setting and apply the theme
                btnTheme.text = selectedTheme
                dialog.dismiss()
                android.widget.Toast.makeText(
                    requireContext(),
                    "Theme set to $selectedTheme",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showDefaultScreenSelectionDialog() {
        val screens = arrayOf("Habits", "Mood", "Hydration", "Settings")
        val currentScreen = "Habits" // In a real app, this would come from settings
        val selectedIndex = screens.indexOf(currentScreen)
        
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select Default Screen")
            .setSingleChoiceItems(screens, selectedIndex) { dialog, which ->
                val selectedScreen = screens[which]
                // In a real app, you would save this setting
                btnDefaultScreen.text = selectedScreen
                dialog.dismiss()
                android.widget.Toast.makeText(
                    requireContext(),
                    "Default screen set to $selectedScreen",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showWaterGoalDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_water, null)
        val etAmount = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_water_amount)
        
        // Pre-fill with current goal
        val currentGoal = prefsManager.getHydrationSettings().dailyGoalMl
        etAmount.setText(currentGoal.toString())
        
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Set Water Goal")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val amountText = etAmount.text?.toString()
                if (!amountText.isNullOrBlank()) {
                    try {
                        val amount = amountText.toInt()
                        if (amount > 0) {
                            val currentSettings = prefsManager.getHydrationSettings()
                            val newSettings = currentSettings.copy(dailyGoalMl = amount)
                            prefsManager.saveHydrationSettings(newSettings)
                            tvWaterGoal.text = "${amount} ml"
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Water goal updated to ${amount} ml",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Please enter a valid amount",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: NumberFormatException) {
                        android.widget.Toast.makeText(
                            requireContext(),
                            "Please enter a valid number",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    android.widget.Toast.makeText(
                        requireContext(),
                        "Please enter an amount",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showAboutDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.about))
            .setMessage(getString(R.string.about_description))
            .setPositiveButton(getString(R.string.ok), null)
            .show()
    }
    
    private fun showResetDataConfirmation() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Reset All Data")
            .setMessage("This will permanently delete all your habits, mood entries, and hydration data. This action cannot be undone.")
            .setPositiveButton("Reset") { _, _ ->
                resetAllData()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    
    private fun resetAllData() {
        // Clear all data from SharedPreferences
        prefsManager.clearAllData()
        
        // Show confirmation message
        android.widget.Toast.makeText(
            requireContext(),
            "All data has been reset",
            android.widget.Toast.LENGTH_LONG
        ).show()
        
        // Optionally, you might want to restart the app or navigate to a setup screen
        // For now, we'll just show a toast
    }
    
    private fun showLogoutConfirmation() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                logout()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    
    private fun logout() {
        // Clear user login status
        prefsManager.setUserLoggedIn(false)
        
        // Navigate to login screen
        val intent = Intent(activity, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        activity?.finish()
    }
}