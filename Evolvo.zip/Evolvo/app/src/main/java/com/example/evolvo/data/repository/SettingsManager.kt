package com.example.evolvo.data.repository

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

/**
 * Utility wrapper for SharedPreferences to manage app settings
 */
class SettingsManager private constructor(context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    companion object {
        private const val PREFS_NAME = "hydralife_settings"
        
        // Keys for settings
        const val KEY_THEME_MODE = "theme_mode"
        const val KEY_REMINDER_INTERVAL = "reminder_interval"
        const val KEY_DEFAULT_SCREEN = "default_screen"
        const val KEY_HABIT_SORTING = "habit_sorting"
        const val KEY_HABIT_FILTERS = "habit_filters"
        const val KEY_WATER_GOAL = "water_goal"
        const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        
        // Default values
        const val DEFAULT_THEME_MODE = "system"
        const val DEFAULT_REMINDER_INTERVAL = 60 // minutes
        const val DEFAULT_DEFAULT_SCREEN = "habits"
        const val DEFAULT_HABIT_SORTING = "name"
        const val DEFAULT_WATER_GOAL = 2000 // ml
        const val DEFAULT_NOTIFICATIONS_ENABLED = true
        
        @Volatile
        private var INSTANCE: SettingsManager? = null
        
        fun getInstance(context: Context): SettingsManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsManager(context).also { INSTANCE = it }
            }
        }
    }
    
    // Theme mode settings
    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, DEFAULT_THEME_MODE) ?: DEFAULT_THEME_MODE
        set(value) = prefs.edit { putString(KEY_THEME_MODE, value).apply() }
    
    // Reminder settings
    var reminderInterval: Int
        get() = prefs.getInt(KEY_REMINDER_INTERVAL, DEFAULT_REMINDER_INTERVAL)
        set(value) = prefs.edit { putInt(KEY_REMINDER_INTERVAL, value).apply() }
    
    var notificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, DEFAULT_NOTIFICATIONS_ENABLED)
        set(value) = prefs.edit { putBoolean(KEY_NOTIFICATIONS_ENABLED, value).apply() }
    
    // Default screen settings
    var defaultScreen: String
        get() = prefs.getString(KEY_DEFAULT_SCREEN, DEFAULT_DEFAULT_SCREEN) ?: DEFAULT_DEFAULT_SCREEN
        set(value) = prefs.edit { putString(KEY_DEFAULT_SCREEN, value).apply() }
    
    // Habit settings
    var habitSorting: String
        get() = prefs.getString(KEY_HABIT_SORTING, DEFAULT_HABIT_SORTING) ?: DEFAULT_HABIT_SORTING
        set(value) = prefs.edit { putString(KEY_HABIT_SORTING, value).apply() }
    
    var habitFilters: String
        get() = prefs.getString(KEY_HABIT_FILTERS, "") ?: ""
        set(value) = prefs.edit { putString(KEY_HABIT_FILTERS, value).apply() }
    
    // Hydration settings
    var waterGoal: Int
        get() = prefs.getInt(KEY_WATER_GOAL, DEFAULT_WATER_GOAL)
        set(value) = prefs.edit { putInt(KEY_WATER_GOAL, value).apply() }
    
    // Listener for preference changes
    fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }
    
    fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }
    
    // Clear all settings
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}