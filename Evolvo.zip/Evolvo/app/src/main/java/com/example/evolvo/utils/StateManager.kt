package com.example.evolvo.utils

import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.view.isVisible
import com.example.evolvo.R

/**
 * Utility class for handling different UI states (loading, empty, error)
 */
class StateManager(
    private val loadingView: View,
    private val emptyView: View,
    private val errorView: View,
    private val contentView: View
) {
    
    /**
     * Show loading state
     */
    fun showLoading() {
        loadingView.isVisible = true
        emptyView.isVisible = false
        errorView.isVisible = false
        contentView.isVisible = false
    }
    
    /**
     * Show empty state
     */
    fun showEmpty() {
        loadingView.isVisible = false
        emptyView.isVisible = true
        errorView.isVisible = false
        contentView.isVisible = false
    }
    
    /**
     * Show error state
     */
    fun showError(message: String? = null, retryAction: (() -> Unit)? = null) {
        loadingView.isVisible = false
        emptyView.isVisible = false
        errorView.isVisible = true
        contentView.isVisible = false
        
        // Set error message if provided
        message?.let {
            val errorTextView = errorView.findViewById<TextView>(R.id.tv_error_message)
            errorTextView?.text = it
        }
        
        // Set retry action if provided
        retryAction?.let {
            val retryButton = errorView.findViewById<Button>(R.id.btn_retry)
            retryButton?.setOnClickListener { retryAction() }
        }
    }
    
    /**
     * Show content state
     */
    fun showContent() {
        loadingView.isVisible = false
        emptyView.isVisible = false
        errorView.isVisible = false
        contentView.isVisible = true
    }
}