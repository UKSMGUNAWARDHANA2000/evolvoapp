package com.example.evolvo.utils

import android.content.Context
import android.util.TypedValue
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.interpolator.view.animation.FastOutSlowInInterpolator

/**
 * Utility class for handling Material 3 motion and animations
 */
object MotionUtils {
    
    /**
     * Apply a shared axis transition animation to a view
     */
    fun applySharedAxisTransition(view: View, axis: SharedAxisAxis = SharedAxisAxis.X) {
        view.apply {
            alpha = 0f
            scaleX = 0.8f
            scaleY = 0.8f
            
            when (axis) {
                SharedAxisAxis.X -> translationX = 100f
                SharedAxisAxis.Y -> translationY = 100f
            }
            
            animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationX(0f)
                .translationY(0f)
                .setDuration(getMediumDuration(context))
                .setInterpolator(FastOutSlowInInterpolator())
                .start()
        }
    }
    
    /**
     * Apply a fade in animation to a view
     */
    fun applyFadeIn(view: View) {
        view.apply {
            alpha = 0f
            animate()
                .alpha(1f)
                .setDuration(getShortDuration(context))
                .setInterpolator(AccelerateDecelerateInterpolator())
                .start()
        }
    }
    
    /**
     * Apply a fade out animation to a view
     */
    fun applyFadeOut(view: View, onEnd: (() -> Unit)? = null) {
        view.animate()
            .alpha(0f)
            .setDuration(getShortDuration(view.context))
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                onEnd?.invoke()
            }
            .start()
    }
    
    /**
     * Get short animation duration from theme
     */
    private fun getShortDuration(context: Context): Long {
        return try {
            val typedValue = TypedValue()
            context.theme.resolveAttribute(android.R.attr.animationDuration, typedValue, true)
            typedValue.data.toLong()
        } catch (e: Exception) {
            200L // Default duration
        }
    }
    
    /**
     * Get medium animation duration from theme
     */
    private fun getMediumDuration(context: Context): Long {
        return try {
            val typedValue = TypedValue()
            context.theme.resolveAttribute(android.R.attr.animationDuration, typedValue, true)
            (typedValue.data * 1.5).toLong()
        } catch (e: Exception) {
            300L // Default duration
        }
    }
    
    /**
     * Get long animation duration from theme
     */
    private fun getLongDuration(context: Context): Long {
        return try {
            val typedValue = TypedValue()
            context.theme.resolveAttribute(android.R.attr.animationDuration, typedValue, true)
            (typedValue.data * 2).toLong()
        } catch (e: Exception) {
            400L // Default duration
        }
    }
}

/**
 * Enum representing shared axis transition directions
 */
enum class SharedAxisAxis {
    X, Y
}