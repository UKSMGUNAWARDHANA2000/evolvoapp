package com.example.evolvo.utils

import android.app.Activity
import android.content.res.Configuration
import androidx.window.layout.WindowMetricsCalculator

/**
 * Utility class for handling window size classes and adaptive layouts
 */
object WindowSizeUtils {
    
    /**
     * Determines the window size class based on width
     */
    fun getWindowSizeClass(activity: Activity): WindowSizeClass {
        val metrics = WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(activity)
        val widthDp = metrics.bounds.width() / activity.resources.displayMetrics.density
        
        return when {
            widthDp < 600 -> WindowSizeClass.COMPACT
            widthDp < 840 -> WindowSizeClass.MEDIUM
            else -> WindowSizeClass.EXPANDED
        }
    }
    
    /**
     * Checks if the device is in landscape mode
     */
    fun isLandscape(activity: Activity): Boolean {
        return activity.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }
}

/**
 * Enum representing Material Design window size classes
 */
enum class WindowSizeClass {
    COMPACT,    // < 600dp
    MEDIUM,     // 600dp - 839dp
    EXPANDED    // >= 840dp
}