package com.example.evolvo.utils

import android.view.LayoutInflater
import android.widget.Button
import com.example.evolvo.R
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/**
 * Utility class for handling bottom sheets
 */
object BottomSheetUtils {
    
    /**
     * Show a quick log bottom sheet
     */
    fun showQuickLogBottomSheet(
        activity: androidx.fragment.app.FragmentActivity,
        onSave: (String) -> Unit
    ) {
        val bottomSheetDialog = BottomSheetDialog(activity)
        val view = LayoutInflater.from(activity).inflate(R.layout.bottom_sheet_quick_log, null)
        bottomSheetDialog.setContentView(view)
        
        val textInputLayout = view.findViewById<TextInputLayout>(R.id.til_quick_log_title)
        val editText = view.findViewById<TextInputEditText>(R.id.et_quick_log_title)
        val saveButton = view.findViewById<Button>(R.id.btn_save)
        val cancelButton = view.findViewById<Button>(R.id.btn_cancel)
        
        saveButton.setOnClickListener {
            val text = editText?.text.toString().trim()
            if (text.isNotEmpty()) {
                onSave(text)
                bottomSheetDialog.dismiss()
            }
        }
        
        cancelButton.setOnClickListener {
            bottomSheetDialog.dismiss()
        }
        
        bottomSheetDialog.show()
    }
}