package com.example.evolvo.ui.dialogs

import android.app.Dialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.example.evolvo.R
import com.example.evolvo.data.models.HydrationSettings
import com.example.evolvo.data.repository.SharedPreferencesManager
import com.example.evolvo.receivers.HydrationAlarmScheduler
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.*

class ReminderSettingsDialogFragment : DialogFragment() {
    
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var etDailyGoal: TextInputEditText
    private lateinit var btnFreq30: MaterialButton
    private lateinit var btnFreq1: MaterialButton
    private lateinit var btnFreq2: MaterialButton
    private lateinit var btnFreq3: MaterialButton
    private lateinit var btnFreq4: MaterialButton
    private lateinit var btnFreqCustom: MaterialButton
    private lateinit var tvReminderTime: TextView
    private lateinit var btnGrantPermission: MaterialButton
    private lateinit var cardNotificationPermission: View
    
    private var selectedInterval = HydrationSettings.INTERVAL_1_HOUR
    private var selectedHour = 8
    private var selectedMinute = 0
    
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        prefsManager = SharedPreferencesManager.getInstance(requireContext())
        
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_reminder_settings, null)
        initializeViews(view)
        loadCurrentSettings()
        setupClickListeners()
        updatePermissionCardVisibility()
        
        return MaterialAlertDialogBuilder(requireContext())
            .setTitle("Reminder Settings")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                saveSettings()
            }
            .setNegativeButton("Cancel", null)
            .create()
    }
    
    private fun initializeViews(view: View) {
        etDailyGoal = view.findViewById(R.id.et_daily_goal)
        btnFreq30 = view.findViewById(R.id.btn_freq_30)
        btnFreq1 = view.findViewById(R.id.btn_freq_1)
        btnFreq2 = view.findViewById(R.id.btn_freq_2)
        btnFreq3 = view.findViewById(R.id.btn_freq_3)
        btnFreq4 = view.findViewById(R.id.btn_freq_4)
        btnFreqCustom = view.findViewById(R.id.btn_freq_custom)
        tvReminderTime = view.findViewById(R.id.tv_reminder_time)
        btnGrantPermission = view.findViewById(R.id.btn_grant_permission)
        cardNotificationPermission = view.findViewById(R.id.card_notification_permission)
    }
    
    private fun loadCurrentSettings() {
        val settings = prefsManager.getHydrationSettings()
        etDailyGoal.setText(settings.dailyGoalMl.toString())
        selectedInterval = settings.reminderIntervalMinutes
        selectedHour = settings.startTime
        selectedMinute = settings.startMinute
        
        // Update UI based on current settings
        updateIntervalButtons()
        updateReminderTimeDisplay()
    }
    
    private fun setupClickListeners() {
        // Frequency buttons
        btnFreq30.setOnClickListener { selectInterval(HydrationSettings.INTERVAL_30_MIN) }
        btnFreq1.setOnClickListener { selectInterval(HydrationSettings.INTERVAL_1_HOUR) }
        btnFreq2.setOnClickListener { selectInterval(HydrationSettings.INTERVAL_2_HOURS) }
        btnFreq3.setOnClickListener { selectInterval(HydrationSettings.INTERVAL_3_HOURS) }
        btnFreq4.setOnClickListener { selectInterval(HydrationSettings.INTERVAL_4_HOURS) }
        btnFreqCustom.setOnClickListener { selectInterval(selectedInterval) } // Keep current custom value
        
        // Reminder time
        tvReminderTime.setOnClickListener {
            showTimePicker()
        }
        
        // Permission button
        btnGrantPermission.setOnClickListener {
            HydrationAlarmScheduler.requestExactAlarmPermission(requireContext())
        }
    }
    
    private fun selectInterval(interval: Int) {
        selectedInterval = interval
        updateIntervalButtons()
    }
    
    private fun updateIntervalButtons() {
        // Reset all buttons
        btnFreq30.isChecked = false
        btnFreq1.isChecked = false
        btnFreq2.isChecked = false
        btnFreq3.isChecked = false
        btnFreq4.isChecked = false
        btnFreqCustom.isChecked = false
        
        // Select the appropriate button
        when (selectedInterval) {
            HydrationSettings.INTERVAL_30_MIN -> btnFreq30.isChecked = true
            HydrationSettings.INTERVAL_1_HOUR -> btnFreq1.isChecked = true
            HydrationSettings.INTERVAL_2_HOURS -> btnFreq2.isChecked = true
            HydrationSettings.INTERVAL_3_HOURS -> btnFreq3.isChecked = true
            HydrationSettings.INTERVAL_4_HOURS -> btnFreq4.isChecked = true
            else -> btnFreqCustom.isChecked = true
        }
    }
    
    private fun showTimePicker() {
        val timePicker = TimePickerDialog(
            requireContext(),
            { _, hourOfDay, minute ->
                selectedHour = hourOfDay
                selectedMinute = minute
                updateReminderTimeDisplay()
            },
            selectedHour,
            selectedMinute,
            android.text.format.DateFormat.is24HourFormat(requireContext())
        )
        timePicker.show()
    }
    
    private fun updateReminderTimeDisplay() {
        val formatter = SimpleDateFormat("h:mm a", Locale.getDefault())
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, selectedHour)
        calendar.set(Calendar.MINUTE, selectedMinute)
        tvReminderTime.text = formatter.format(calendar.time)
    }
    
    private fun updatePermissionCardVisibility() {
        if (HydrationAlarmScheduler.canScheduleExactAlarms(requireContext())) {
            cardNotificationPermission.visibility = View.GONE
        } else {
            cardNotificationPermission.visibility = View.VISIBLE
        }
    }
    
    private fun saveSettings() {
        val goalText = etDailyGoal.text?.toString()
        if (goalText.isNullOrBlank()) {
            android.widget.Toast.makeText(
                context,
                "Please enter a water goal",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            return
        }
        
        try {
            val goal = goalText.toInt()
            if (goal < HydrationSettings.MIN_GOAL || goal > HydrationSettings.MAX_GOAL) {
                android.widget.Toast.makeText(
                    context,
                    "Goal must be between ${HydrationSettings.MIN_GOAL}ml and ${HydrationSettings.MAX_GOAL}ml",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
                return
            }
            
            // Save settings
            val currentSettings = prefsManager.getHydrationSettings()
            val newSettings = currentSettings.copy(
                dailyGoalMl = goal,
                reminderIntervalMinutes = selectedInterval,
                startTime = selectedHour,
                startMinute = selectedMinute,
                reminderEnabled = true,
                lastUpdated = Date()
            )
            
            prefsManager.saveHydrationSettings(newSettings)
            
            // Schedule the alarm
            HydrationAlarmScheduler.scheduleRecurringAlarmWithMinutes(
                requireContext(),
                newSettings,
                selectedMinute
            )
            
            android.widget.Toast.makeText(
                context,
                "Reminder settings saved",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            
        } catch (e: NumberFormatException) {
            android.widget.Toast.makeText(
                context,
                "Please enter a valid number",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }
}