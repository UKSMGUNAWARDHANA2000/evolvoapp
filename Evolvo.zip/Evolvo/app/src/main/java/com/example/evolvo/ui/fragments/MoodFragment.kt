package com.example.evolvo.ui.fragments

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.evolvo.R
import com.example.evolvo.data.models.MoodEntry
import com.example.evolvo.data.models.MoodType
import com.example.evolvo.data.repository.SharedPreferencesManager
import com.example.evolvo.ui.adapters.MoodSelectorAdapter
import com.example.evolvo.ui.adapters.MoodHistoryAdapter
import com.example.evolvo.ui.charts.MoodChartHelper
import com.example.evolvo.ui.charts.MoodStatisticsHelper
import com.github.mikephil.charting.charts.LineChart
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import java.text.SimpleDateFormat
import java.util.*

/**
 * Fragment for mood journaling with emoji selector
 */
class MoodFragment : BaseFragment() {
    
    private lateinit var recyclerMoodSelector: RecyclerView
    private lateinit var recyclerMoodHistory: RecyclerView
    private lateinit var btnSaveMood: MaterialButton
    private lateinit var fabQuickLog: FloatingActionButton
    private lateinit var tabLayoutMoodView: TabLayout
    private lateinit var layoutMoodCalendar: View
    private lateinit var etMoodNotes: EditText
    
    // New views for enhanced UI
    private lateinit var tvTodaysMood: TextView
    private lateinit var tvWeeklyAverage: TextView
    private lateinit var layoutEmptyState: View
    private lateinit var chartContainer: FrameLayout

    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var moodSelectorAdapter: MoodSelectorAdapter
    private lateinit var moodHistoryAdapter: MoodHistoryAdapter
    private lateinit var moodChartHelper: MoodChartHelper
    private lateinit var moodStatsHelper: MoodStatisticsHelper
    
    private var selectedMood: MoodType? = null
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_mood, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize components
        initializeViews(view)
        setupMoodSelector()
        setupMoodHistory()
        setupMoodViewTabs()
        setupClickListeners()
        loadMoodHistory()
        updateMoodSummary()
    }
    
    override fun onResume() {
        super.onResume()
        loadMoodHistory()
        updateMoodSummary()
        updateMoodChart() // Add this line to update the chart when fragment resumes
    }
    
    private fun initializeViews(view: View) {
        prefsManager = SharedPreferencesManager.getInstance(requireContext())
        moodChartHelper = MoodChartHelper(requireContext())
        moodStatsHelper = MoodStatisticsHelper(prefsManager)
        recyclerMoodSelector = view.findViewById(R.id.recycler_mood_selector)
        recyclerMoodHistory = view.findViewById(R.id.recycler_mood_history)
        btnSaveMood = view.findViewById(R.id.btn_save_mood)
        fabQuickLog = view.findViewById(R.id.fab_quick_log)
        tabLayoutMoodView = view.findViewById(R.id.tab_layout_mood_view)
        layoutMoodCalendar = view.findViewById(R.id.layout_mood_calendar)
        etMoodNotes = view.findViewById(R.id.et_mood_notes)
        layoutEmptyState = view.findViewById(R.id.layout_empty_mood_history)
        chartContainer = view.findViewById(R.id.chart_container)
        
        // New views for enhanced UI
        tvTodaysMood = view.findViewById(R.id.tv_todays_mood)
        tvWeeklyAverage = view.findViewById(R.id.tv_weekly_average)
    }
    
    private fun setupMoodSelector() {
        moodSelectorAdapter = MoodSelectorAdapter { mood ->
            selectedMood = mood
            updateSaveButtonState()
        }
        
        recyclerMoodSelector.apply {
            layoutManager = GridLayoutManager(context, 5) // 5 columns for emojis
            adapter = moodSelectorAdapter
            setHasFixedSize(true)
        }
        
        // Load all available moods
        moodSelectorAdapter.updateMoods(MoodType.getAllMoods())
    }
    
    private fun setupMoodHistory() {
        moodHistoryAdapter = MoodHistoryAdapter(
            onDeleteClick = { entry -> deleteMoodEntry(entry) },
            onShareClick = { entry -> shareMoodEntry(entry) }
        )
        
        recyclerMoodHistory.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = moodHistoryAdapter
            setHasFixedSize(true)
        }
    }
    
    private fun setupMoodViewTabs() {
        // Add tabs for List and Calendar views
        val listTab = tabLayoutMoodView.newTab().setText("List")
        val calendarTab = tabLayoutMoodView.newTab().setText("Calendar")
        tabLayoutMoodView.addTab(listTab)
        tabLayoutMoodView.addTab(calendarTab)
        
        // Set up tab listener
        tabLayoutMoodView.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> showListView()
                    1 -> showCalendarView()
                }
            }
            
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }
    
    private fun setupClickListeners() {
        btnSaveMood.setOnClickListener {
            saveMoodEntry()
        }
        
        fabQuickLog.setOnClickListener {
            showQuickMoodDialog()
        }
        
        // Initialize with list view
        showListView()
    }
    
    private fun updateSaveButtonState() {
        btnSaveMood.isEnabled = selectedMood != null
    }
    
    private fun saveMoodEntry() {
        val mood = selectedMood ?: return
        val notes = etMoodNotes.text.toString().trim()
        
        val moodEntry = MoodEntry(
            mood = mood,
            emoji = mood.emoji,
            notes = notes,
            timestamp = Date()
        )
        
        prefsManager.saveMoodEntry(moodEntry)
        
        // Clear selection and notes
        selectedMood = null
        moodSelectorAdapter.clearSelection()
        etMoodNotes.setText("")
        updateSaveButtonState()
        
        // Refresh UI
        loadMoodHistory()
        updateMoodSummary()
        updateMoodChart() // Add this line to update the chart when a new mood is saved
        
        // Show success message
        android.widget.Toast.makeText(
            requireContext(),
            "Mood entry saved successfully!",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
    
    private fun loadMoodHistory() {
        val moodEntries = prefsManager.getTodayMoodEntries()
        moodHistoryAdapter.updateMoodEntries(moodEntries)
        
        // Show/hide empty state
        layoutEmptyState.visibility = if (moodEntries.isEmpty()) View.VISIBLE else View.GONE
    }
    
    private fun showListView() {
        recyclerMoodHistory.visibility = View.VISIBLE
        layoutMoodCalendar.visibility = View.GONE
    }
    
    private fun showCalendarView() {
        recyclerMoodHistory.visibility = View.GONE
        layoutMoodCalendar.visibility = View.VISIBLE
        
        // Clear existing views
        if (layoutMoodCalendar is ViewGroup) {
            (layoutMoodCalendar as ViewGroup).removeAllViews()
        }
        
        // Create a simple layout for the calendar view
        val mainLayout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        
        // Add title
        val titleText = TextView(requireContext()).apply {
            text = "Mood History"
            setTextColor(requireContext().getColor(R.color.text_primary))
            textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 16, 16, 16)
        }
        mainLayout.addView(titleText)
        
        // Add instruction text
        val instructionText = TextView(requireContext()).apply {
            text = "All your mood entries"
            setTextColor(requireContext().getColor(R.color.text_secondary))
            textSize = 14f
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 0, 16, 16)
        }
        mainLayout.addView(instructionText)
        
        // Add mood list container
        val moodListContainer = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 0, 16, 16)
        }
        mainLayout.addView(moodListContainer)
        
        // Load all mood entries
        loadAllMoodEntries(moodListContainer)
        
        // Add scroll view to the calendar layout
        val scrollView = android.widget.ScrollView(requireContext())
        scrollView.addView(mainLayout)
        
        if (layoutMoodCalendar is ViewGroup) {
            (layoutMoodCalendar as ViewGroup).addView(scrollView)
        }
    }
    
    private fun loadAllMoodEntries(container: LinearLayout) {
        // Clear existing views
        container.removeAllViews()
        
        // Load all mood entries
        val moodEntries = prefsManager.getMoodEntries()
        
        if (moodEntries.isEmpty()) {
            // Show empty state
            val emptyText = TextView(requireContext()).apply {
                text = "No mood entries yet"
                setTextColor(requireContext().getColor(R.color.text_secondary))
                textSize = 16f
                gravity = android.view.Gravity.CENTER
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                setPadding(0, 32, 0, 32)
            }
            container.addView(emptyText)
        } else {
            // Group entries by date
            val entriesByDate = moodEntries.groupBy { it.date }
            
            // Sort dates in descending order (newest first)
            val sortedDates = entriesByDate.keys.sortedDescending()
            
            // Add each date group
            for (date in sortedDates) {
                val entries = entriesByDate[date] ?: continue
                
                // Add date header
                val displayDateFormat = SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault())
                val dateObj = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(date)
                
                val dateHeader = TextView(requireContext()).apply {
                    text = dateObj?.let { displayDateFormat.format(it) } ?: date
                    setTextColor(requireContext().getColor(R.color.text_primary))
                    textSize = 18f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    setPadding(0, 16, 0, 8)
                }
                container.addView(dateHeader)
                
                // Add each mood entry for this date
                for (entry in entries) {
                    val entryView = createMoodEntryView(entry)
                    container.addView(entryView)
                }
            }
        }
    }
    
    // Remove the other calendar-related methods that were causing issues
    private fun populateDateSelector(dateContainer: LinearLayout) {
        // This method is no longer needed
    }
    
    private fun createDayView(date: Date, dateContainer: LinearLayout): View {
        // This method is no longer needed
        return TextView(requireContext())
    }
    
    private fun highlightSelectedDate(selectedView: View, dateContainer: ViewGroup) {
        // This method is no longer needed
    }
    
    private fun loadMoodEntriesForDate(date: String, parentView: ViewGroup) {
        // This method is no longer needed
    }
    
    private fun createMoodEntryView(entry: MoodEntry): View {
        val cardView = com.google.android.material.card.MaterialCardView(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setCardBackgroundColor(requireContext().getColor(R.color.surface))
            radius = 16f
            cardElevation = 4f
            setUseCompatPadding(true)
        }
        
        val entryLayout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 16, 16, 16)
        }
        
        // Mood emoji and label
        val moodText = TextView(requireContext()).apply {
            text = "${entry.emoji} ${entry.mood.label}"
            setTextColor(requireContext().getColor(R.color.text_primary))
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        entryLayout.addView(moodText)
        
        // Timestamp
        val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
        val timestampText = TextView(requireContext()).apply {
            text = timeFormat.format(entry.timestamp)
            setTextColor(requireContext().getColor(R.color.text_secondary))
            textSize = 14f
            setPadding(0, 4, 0, 8)
        }
        entryLayout.addView(timestampText)
        
        // Notes (if any)
        if (entry.notes.isNotEmpty()) {
            val notesText = TextView(requireContext()).apply {
                text = entry.notes
                setTextColor(requireContext().getColor(R.color.text_secondary))
                textSize = 16f
                setPadding(0, 8, 0, 0)
            }
            entryLayout.addView(notesText)
        }
        
        cardView.addView(entryLayout)
        return cardView
    }
    
    private fun isSameDay(date1: Date, date2: Date): Boolean {
        val cal1 = Calendar.getInstance()
        val cal2 = Calendar.getInstance()
        cal1.time = date1
        cal2.time = date2
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    private fun deleteMoodEntry(entry: MoodEntry) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Mood Entry")
            .setMessage("Are you sure you want to delete this mood entry?")
            .setPositiveButton("Delete") { _, _ ->
                prefsManager.deleteMoodEntry(entry.id)
                loadMoodHistory()
                updateMoodSummary()
                updateMoodChart() // Add this line to update the chart when a mood is deleted
                android.widget.Toast.makeText(
                    requireContext(),
                    "Mood entry deleted",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    
    private fun shareMoodEntry(entry: MoodEntry) {
        val shareText = "My mood today: ${entry.emoji} ${entry.mood.label}${if (entry.notes.isNotEmpty()) "\nNotes: ${entry.notes}" else ""}"
        
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        
        startActivity(Intent.createChooser(shareIntent, getString(R.string.share_via)))
    }
    
    private fun shareTodaysMood() {
        val todayEntries = prefsManager.getTodayMoodEntries()
        if (todayEntries.isEmpty()) {
            android.widget.Toast.makeText(
                requireContext(),
                "No mood entries to share today",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            return
        }
        
        val latestEntry = todayEntries.lastOrNull()
        if (latestEntry != null) {
            shareMoodEntry(latestEntry)
        }
    }
    
    private fun showMoodStatisticsDialog() {
        // TODO: Implement mood statistics dialog
        android.widget.Toast.makeText(
            requireContext(),
            "Mood statistics feature coming soon",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
    
    private fun updateMoodSummary() {
        // Update today's mood
        val todayEntries = prefsManager.getTodayMoodEntries()
        if (todayEntries.isNotEmpty()) {
            val latestMood = todayEntries.last().mood
            tvTodaysMood.text = latestMood.emoji
        } else {
            tvTodaysMood.text = "😐"
        }
        
        // Update weekly average
        val weeklyEntries = prefsManager.getWeeklyMoodEntries()
        if (weeklyEntries.isNotEmpty()) {
            // Simple average calculation - in a real app, you might want a more sophisticated approach
            val moodMap = mutableMapOf<MoodType, Int>()
            for (entry in weeklyEntries) {
                moodMap[entry.mood] = moodMap.getOrDefault(entry.mood, 0) + 1
            }
            
            val mostFrequentMood = moodMap.maxByOrNull { it.value }?.key
            if (mostFrequentMood != null) {
                tvWeeklyAverage.text = mostFrequentMood.emoji
            } else {
                tvWeeklyAverage.text = "😐"
            }
        } else {
            tvWeeklyAverage.text = "😐"
        }
    }
    
    private fun updateMoodChart() {
        // Get mood entries for the past week
        val weeklyEntries = prefsManager.getWeeklyMoodEntries()
        
        // If we have entries, create and display the chart
        if (weeklyEntries.isNotEmpty()) {
            // Remove placeholder text
            chartContainer.removeAllViews()
            
            // Create a LineChart and set it up using MoodChartHelper
            val chart = LineChart(requireContext())
            chart.layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            
            // Set chart background to match the container
            chart.setBackgroundColor(requireContext().getColor(R.color.surface))
            
            moodChartHelper.setupMoodTrendChart(chart, weeklyEntries)
            chartContainer.addView(chart)
        }
        // If no entries, keep the placeholder text
    }
    
    private fun showQuickMoodDialog() {
        val moodTypes = MoodType.getAllMoods()
        val emojis = moodTypes.map { it.emoji }.toTypedArray()
        val labels = moodTypes.map { it.label }.toTypedArray()
        
        AlertDialog.Builder(requireContext())
            .setTitle("Quick Mood Log")
            .setItems(emojis) { _, which ->
                val selectedMood = moodTypes[which]
                val moodEntry = MoodEntry(
                    mood = selectedMood,
                    emoji = selectedMood.emoji,
                    notes = "",
                    timestamp = Date()
                )
                prefsManager.saveMoodEntry(moodEntry)
                loadMoodHistory()
                updateMoodSummary()
                updateMoodChart() // Add this line to update the chart when a quick mood is saved
                android.widget.Toast.makeText(
                    requireContext(),
                    "Quick mood logged!",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            .show()
    }
}