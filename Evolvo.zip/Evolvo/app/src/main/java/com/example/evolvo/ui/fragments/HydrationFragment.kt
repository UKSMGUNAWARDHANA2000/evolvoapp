package com.example.evolvo.ui.fragments

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.evolvo.R
import com.example.evolvo.data.models.HydrationIntake
import com.example.evolvo.data.repository.SharedPreferencesManager
import com.example.evolvo.ui.adapters.HydrationHistoryAdapter
import com.example.evolvo.ui.charts.HydrationStatisticsHelper
import com.example.evolvo.ui.dialogs.ReminderSettingsDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.*

/**
 * Fragment for hydration tracking and reminders
 */
class HydrationFragment : BaseFragment() {
    
    private lateinit var tvDailyGoal: TextView
    private lateinit var tvCurrentIntake: TextView
    private lateinit var recyclerHydrationHistory: RecyclerView
    private lateinit var progressHydration: LinearProgressIndicator
    private lateinit var fabQuickAdd: FloatingActionButton
    private lateinit var btnHydrationSettings: MaterialButton
    
    // New views for enhanced UI
    private lateinit var tvIntakePercentage: TextView
    private lateinit var tvEntriesCount: TextView
    private lateinit var tvHydrationStreak: TextView
    private lateinit var layoutEmptyState: View
    
    // Quick add buttons
    private lateinit var btnQuickAdd100: MaterialButton
    private lateinit var btnQuickAdd250: MaterialButton
    private lateinit var btnQuickAdd330: MaterialButton
    private lateinit var btnQuickAdd500: MaterialButton
    private lateinit var btnQuickAdd750: MaterialButton
    private lateinit var btnQuickAdd1000: MaterialButton
    private lateinit var btnQuickAdd1500: MaterialButton
    private lateinit var btnCustomAmount: MaterialButton
    
    // Manual entry views
    private lateinit var tvWaterGoalValue: TextView
    private lateinit var btnEditWaterGoal: MaterialButton
    private lateinit var tvReminderStatus: TextView
    private lateinit var btnEditReminder: MaterialButton
    private lateinit var etCustomAmount: TextInputEditText
    private lateinit var btnAddCustom: MaterialButton
    
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var hydrationHistoryAdapter: HydrationHistoryAdapter
    private lateinit var hydrationStatsHelper: HydrationStatisticsHelper
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_hydration, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize components
        initializeViews(view)
        setupHydrationHistory()
        setupClickListeners()
        updateHydrationDisplay()
    }
    
    override fun onResume() {
        super.onResume()
        updateHydrationDisplay()
    }
    
    private fun initializeViews(view: View) {
        prefsManager = SharedPreferencesManager.getInstance(requireContext())
        hydrationStatsHelper = HydrationStatisticsHelper(prefsManager)
        
        // Views for enhanced UI
        tvDailyGoal = view.findViewById(R.id.tv_daily_goal)
        tvCurrentIntake = view.findViewById(R.id.tv_current_intake)
        recyclerHydrationHistory = view.findViewById(R.id.recycler_hydration_history)
        progressHydration = view.findViewById(R.id.progress_hydration)
        fabQuickAdd = view.findViewById(R.id.fab_quick_add)
        btnHydrationSettings = view.findViewById(R.id.btn_hydration_settings)
        layoutEmptyState = view.findViewById(R.id.layout_empty_hydration)
        
        // New views for enhanced UI
        tvIntakePercentage = view.findViewById(R.id.tv_intake_percentage)
        tvEntriesCount = view.findViewById(R.id.tv_entries_count)
        tvHydrationStreak = view.findViewById(R.id.tv_hydration_streak)
        
        // Quick add buttons
        btnQuickAdd100 = view.findViewById(R.id.btn_quick_add_100)
        btnQuickAdd250 = view.findViewById(R.id.btn_quick_add_250)
        btnQuickAdd330 = view.findViewById(R.id.btn_quick_add_330)
        btnQuickAdd500 = view.findViewById(R.id.btn_quick_add_500)
        btnQuickAdd750 = view.findViewById(R.id.btn_quick_add_750)
        btnQuickAdd1000 = view.findViewById(R.id.btn_quick_add_1000)
        btnQuickAdd1500 = view.findViewById(R.id.btn_quick_add_1500)
        btnCustomAmount = view.findViewById(R.id.btn_custom_amount)
        
        // Manual entry views
        tvWaterGoalValue = view.findViewById(R.id.tv_water_goal_value)
        btnEditWaterGoal = view.findViewById(R.id.btn_edit_water_goal)
        tvReminderStatus = view.findViewById(R.id.tv_reminder_status)
        btnEditReminder = view.findViewById(R.id.btn_edit_reminder)
        etCustomAmount = view.findViewById(R.id.et_custom_amount)
        btnAddCustom = view.findViewById(R.id.btn_add_custom)
    }
    
    private fun setupHydrationHistory() {
        hydrationHistoryAdapter = HydrationHistoryAdapter()
        
        recyclerHydrationHistory.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = hydrationHistoryAdapter
            setHasFixedSize(true)
        }
    }
    
    private fun setupClickListeners() {
        // Quick add buttons
        btnQuickAdd100.setOnClickListener { addWaterIntake(100) }
        btnQuickAdd250.setOnClickListener { addWaterIntake(250) }
        btnQuickAdd330.setOnClickListener { addWaterIntake(330) }
        btnQuickAdd500.setOnClickListener { addWaterIntake(500) }
        btnQuickAdd750.setOnClickListener { addWaterIntake(750) }
        btnQuickAdd1000.setOnClickListener { addWaterIntake(1000) }
        btnQuickAdd1500.setOnClickListener { addWaterIntake(1500) }
        
        // Custom amount
        btnCustomAmount.setOnClickListener {
            showAddWaterDialog()
        }
        
        btnAddCustom.setOnClickListener {
            val amountText = etCustomAmount.text?.toString()
            if (!amountText.isNullOrBlank()) {
                try {
                    val amount = amountText.toInt()
                    if (amount > 0) {
                        addWaterIntake(amount)
                        etCustomAmount.text?.clear()
                    } else {
                        android.widget.Toast.makeText(
                            requireContext(),
                            "Please enter a valid amount",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: NumberFormatException) {
                    android.widget.Toast.makeText(
                        requireContext(),
                        "Please enter a valid number",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                android.widget.Toast.makeText(
                    requireContext(),
                    "Please enter an amount",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
        
        fabQuickAdd.setOnClickListener {
            showQuickAddOptions()
        }
        
        // Settings button
        btnHydrationSettings.setOnClickListener {
            showReminderSettingsDialog()
        }
        
        // Manual entry settings
        btnEditWaterGoal.setOnClickListener {
            showWaterGoalDialog()
        }
        
        btnEditReminder.setOnClickListener {
            showReminderSettingsDialog()
        }
    }
    
    private fun addWaterIntake(amountMl: Int) {
        val today = dateFormat.format(Date())
        val intake = HydrationIntake(
            date = today,
            amountMl = amountMl,
            timestamp = Date()
        )
        
        prefsManager.addHydrationIntake(intake)
        
        // Check if user has reached their goal and send notification if so
        val settings = prefsManager.getHydrationSettings()
        val totalIntake = prefsManager.getDailyTotalHydration(today)
        if (totalIntake >= settings.dailyGoalMl) {
            // Send goal reached notification
            sendGoalReachedNotification()
        }
        
        updateHydrationDisplay()
        
        android.widget.Toast.makeText(
            requireContext(),
            "Added $amountMl ml of water",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
    
    private fun sendGoalReachedNotification() {
        // Create intent to send to the HydrationAlarmReceiver to handle the notification
        val intent = Intent(requireContext(), com.example.evolvo.receivers.HydrationAlarmReceiver::class.java)
        // We'll add an extra to indicate this is a goal reached notification
        intent.putExtra("goal_reached", true)
        
        // Use a foreground service approach by sending the broadcast directly
        requireContext().sendBroadcast(intent)
    }
    
    private fun updateHydrationDisplay() {
        val today = dateFormat.format(Date())
        val totalIntake = prefsManager.getDailyTotalHydration(today)
        val settings = prefsManager.getHydrationSettings()
        val goal = settings.dailyGoalMl
        // Ensure proper floating-point calculation for percentage
        val percentage = if (goal > 0) {
            ((totalIntake.toFloat() * 100) / goal.toFloat()).coerceAtMost(100f).toInt()
        } else {
            0
        }
        
        // Update UI elements on the main thread
        requireActivity().runOnUiThread {
            tvCurrentIntake.text = "${totalIntake} ml"
            tvDailyGoal.text = "${goal} ml"
            tvWaterGoalValue.text = "${goal} ml"
            tvIntakePercentage.text = "$percentage%"
            
            // Update progress bar
            progressHydration.progress = percentage
            
            // Force UI refresh
            progressHydration.invalidate()
            tvCurrentIntake.invalidate()
            tvDailyGoal.invalidate()
            tvWaterGoalValue.invalidate()
            tvIntakePercentage.invalidate()
        }
        
        // Update reminder status
        if (settings.reminderEnabled) {
            val timeFormatter = SimpleDateFormat("h:mm a", Locale.getDefault())
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, settings.startTime)
            calendar.set(Calendar.MINUTE, settings.startMinute)
            tvReminderStatus.text = "Enabled • ${timeFormatter.format(calendar.time)}"
        } else {
            tvReminderStatus.text = "Disabled"
        }
        
        // Update entries count
        val todayEntries = prefsManager.getHydrationIntakeForDay(today)
        tvEntriesCount.text = "${todayEntries.size} ${if (todayEntries.size == 1) "entry" else "entries"}"
        
        // Update hydration history
        hydrationHistoryAdapter.updateIntakes(todayEntries)
        
        // Show/hide empty state
        layoutEmptyState.visibility = if (todayEntries.isEmpty()) View.VISIBLE else View.GONE
        
        // Update streak (simplified for this example)
        tvHydrationStreak.text = "3 day streak" // In a real app, this would be calculated
    }
    
    private fun showAddWaterDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_water, null)
        val etAmount = view.findViewById<TextInputEditText>(R.id.et_water_amount)
        
        AlertDialog.Builder(requireContext())
            .setTitle("Add Water Intake")
            .setView(view)
            .setPositiveButton("Add") { _, _ ->
                val amountText = etAmount.text?.toString()
                if (!amountText.isNullOrBlank()) {
                    try {
                        val amount = amountText.toInt()
                        if (amount > 0) {
                            addWaterIntake(amount)
                        } else {
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Please enter a valid amount",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: NumberFormatException) {
                        android.widget.Toast.makeText(
                            requireContext(),
                            "Please enter a valid number",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    android.widget.Toast.makeText(
                        requireContext(),
                        "Please enter an amount",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showQuickAddOptions() {
        val options = arrayOf("100 ml", "250 ml", "330 ml", "500 ml", "750 ml", "1000 ml", "Custom")
        AlertDialog.Builder(requireContext())
            .setTitle("Quick Add Water")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> addWaterIntake(100)
                    1 -> addWaterIntake(250)
                    2 -> addWaterIntake(330)
                    3 -> addWaterIntake(500)
                    4 -> addWaterIntake(750)
                    5 -> addWaterIntake(1000)
                    6 -> showAddWaterDialog()
                }
            }
            .show()
    }
    
    private fun showReminderSettingsDialog() {
        val dialog = ReminderSettingsDialogFragment()
        dialog.show(parentFragmentManager, "ReminderSettingsDialog")
    }
    
    private fun showWaterGoalDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_water, null)
        val etAmount = view.findViewById<TextInputEditText>(R.id.et_water_amount)
        
        // Pre-fill with current goal
        val currentGoal = prefsManager.getHydrationSettings().dailyGoalMl
        etAmount.setText(currentGoal.toString())
        
        AlertDialog.Builder(requireContext())
            .setTitle("Set Water Goal")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val amountText = etAmount.text?.toString()
                if (!amountText.isNullOrBlank()) {
                    try {
                        val amount = amountText.toInt()
                        if (amount >= 500 && amount <= 5000) {
                            val currentSettings = prefsManager.getHydrationSettings()
                            val newSettings = currentSettings.copy(dailyGoalMl = amount)
                            prefsManager.saveHydrationSettings(newSettings)
                            updateHydrationDisplay()
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Water goal updated to ${amount} ml",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Goal must be between 500ml and 5000ml",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: NumberFormatException) {
                        android.widget.Toast.makeText(
                            requireContext(),
                            "Please enter a valid number",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    android.widget.Toast.makeText(
                        requireContext(),
                        "Please enter an amount",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showHydrationStatisticsDialog() {
        // TODO: Implement hydration statistics dialog
        android.widget.Toast.makeText(
            requireContext(),
            "Hydration statistics feature coming soon",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
}