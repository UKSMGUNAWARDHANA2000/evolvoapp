package com.example.evolvo.receivers

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.evolvo.data.models.Habit
import com.example.evolvo.data.repository.SharedPreferencesManager

/**
 * Scheduler for habit goal reached notifications
 */
object HabitNotificationScheduler {
    
    /**
     * Schedule a notification for when a habit reaches its daily goal
     */
    fun scheduleHabitNotification(context: Context, habit: Habit) {
        val prefsManager = SharedPreferencesManager.getInstance(context)
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val progress = prefsManager.getHabitProgressForDay(habit.id, today)
        
        // Only schedule if the habit hasn't been completed yet
        if (progress == null || progress.currentValue < habit.targetValue) {
            // For simplicity, we'll trigger an immediate check
            // In a real app, you might want to schedule this for specific times
            triggerHabitCheck(context, habit)
        }
    }
    
    /**
     * Trigger an immediate check for habit completion
     */
    private fun triggerHabitCheck(context: Context, habit: Habit) {
        val intent = Intent(context, HabitNotificationReceiver::class.java).apply {
            putExtra("habit_id", habit.id)
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            habit.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        // Send the broadcast immediately
        context.sendBroadcast(intent)
    }
    
    /**
     * Cancel a scheduled habit notification
     */
    fun cancelHabitNotification(context: Context, habitId: String) {
        val intent = Intent(context, HabitNotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            habitId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent)
    }
    
    /**
     * Check all habits and schedule notifications for those that might reach their goals
     */
    fun checkAllHabits(context: Context) {
        val prefsManager = SharedPreferencesManager.getInstance(context)
        val habits = prefsManager.getHabits()
        
        for (habit in habits) {
            scheduleHabitNotification(context, habit)
        }
    }
}