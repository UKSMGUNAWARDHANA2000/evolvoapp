package com.example.evolvo

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.example.evolvo.data.models.UserMetrics
import com.example.evolvo.data.repository.SharedPreferencesManager
import com.example.evolvo.receivers.HydrationAlarmScheduler
import com.example.evolvo.ui.auth.LoginActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
// Removed NavigationRailView import since we're not using it anymore

class MainActivity : AppCompatActivity() {
    
    private lateinit var navController: NavController
    private lateinit var bottomNavigation: BottomNavigationView
    // Removed navigationRail since we're not using it anymore
    private lateinit var prefsManager: SharedPreferencesManager
    
    // Permission request code
    private val PERMISSION_REQUEST_CODE = 1001
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set up the View System UI
        setupViewSystemUI()
        
        // Check if user is logged in
        prefsManager = SharedPreferencesManager.getInstance(this)
        if (!prefsManager.isUserLoggedIn()) {
            // Redirect to login screen
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
            return
        }
        
        // Initialize default metrics if they don't exist
        initializeDefaultMetrics()
        
        // Check and request notification permissions on app start
        checkAndRequestNotificationPermission()
        
        // Check and request exact alarm permissions on app start
        checkAndRequestExactAlarmPermission()
        
        // Handle intent extras
        handleIntent(intent)
    }
    
    private fun initializeDefaultMetrics() {
        // Check if metrics already exist
        val currentMetrics = prefsManager.getUserMetrics()
        
        // If all values are zero, initialize with default values
        if (currentMetrics.calories == 0f && currentMetrics.heartRate == 0 && 
            currentMetrics.weight == 0f && currentMetrics.steps == 0) {
            
            val defaultMetrics = UserMetrics(
                calories = 620.68f,
                heartRate = 72,
                weight = 89.5f,
                steps = 5423
            )
            
            prefsManager.saveUserMetrics(defaultMetrics)
        }
    }
    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }
    
    override fun onResume() {
        super.onResume()
        // No need to update navigation based on window size anymore
    }
    
    override fun onPause() {
        super.onPause()
    }
    
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // No need to update navigation when configuration changes anymore
    }
    
    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    
    private fun checkAndRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Show explanation dialog before requesting permission
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Notification Permission Required")
                    .setMessage("WellnesMate needs notification permission to send you hydration reminders. Please grant this permission to receive timely reminders.")
                    .setPositiveButton("Grant Permission") { _, _ ->
                        ActivityCompat.requestPermissions(
                            this,
                            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                            PERMISSION_REQUEST_CODE
                        )
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }
    
    private fun checkAndRequestExactAlarmPermission() {
        // Only check on Android 12+ (API 31)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!HydrationAlarmScheduler.canScheduleExactAlarms(this)) {
                // Show explanation dialog before requesting permission
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Exact Alarm Permission Required")
                    .setMessage("WellnesMate needs permission to schedule exact alarms for precise hydration reminders. Please grant this permission to receive timely reminders.")
                    .setPositiveButton("Grant Permission") { _, _ ->
                        HydrationAlarmScheduler.requestExactAlarmPermission(this)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    android.widget.Toast.makeText(
                        this,
                        "Notification permission granted. You'll now receive hydration reminders!",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                } else {
                    // Show explanation why permission is needed
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Permission Required")
                        .setMessage("Without notification permission, you won't receive hydration reminders. You can enable this permission later in Settings > Apps > WellnesMate > Permissions.")
                        .setPositiveButton("Open Settings") { _, _ ->
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            )
                            val uri = android.net.Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            startActivity(intent)
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }
    }
    
    private fun setupViewSystemUI() {
        setContentView(R.layout.activity_main)
        
        // Initialize navigation components
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController
        
        // Initialize bottom navigation only
        bottomNavigation = findViewById(R.id.bottom_navigation)
        // Removed navigationRail initialization
        
        // Set up navigation with NavController (bottom navigation only)
        bottomNavigation.setupWithNavController(navController)
        
        // Set up window insets for proper layout handling
        setupWindowInsets()
    }
    
    private fun handleIntent(intent: Intent) {
        when {
            intent.getBooleanExtra("open_hydration", false) -> {
                // Handle quick add water from notification
                if (intent.getBooleanExtra("quick_add_water", false)) {
                    // Add default amount of water (250ml)
                    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
                    val intake = com.example.evolvo.data.models.HydrationIntake(
                        date = today,
                        amountMl = 250,
                        timestamp = java.util.Date()
                    )
                    prefsManager.addHydrationIntake(intake)
                    
                    android.widget.Toast.makeText(
                        this,
                        "Added 250ml of water",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
                
                // Switch to hydration tab
                navController.navigate(R.id.nav_hydration)
            }
        }
    }
}