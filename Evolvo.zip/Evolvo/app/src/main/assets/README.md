# TrackBloom - Modern Android Wellness Tracker

## Project Overview
TrackBloom is a modern Android wellness tracking application that helps users build and maintain healthy habits, track their mood, and stay hydrated. This project demonstrates a complete migration from a traditional Fragment-based architecture to a modern single-activity architecture with Material 3 components.

## Key Features
- Habit tracking with progress visualization
- Mood journal with calendar view
- Hydration tracker with reminders
- Settings management
- Adaptive layouts for phones, tablets, and foldables
- Material 3 design system
- Edge-to-edge support
- Accessibility features

## Architecture
- **Single-Activity Architecture**: Uses Navigation Component for fragment-based navigation
- **Material 3 Design**: Implements Material Design 3 components and principles
- **Adaptive Layouts**: Supports different screen sizes using Window Size Classes
- **Data Persistence**: SharedPreferences for local data storage
- **Utility Classes**: Modular utility classes for common functionality

## Project Structure
```
app/
├── src/
│   ├── main/
│   │   ├── java/com/example/trackbloom/
│   │   │   ├── data/
│   │   │   │   └── repository/
│   │   │   │       ├── SharedPreferencesManager.kt
│   │   │   │       └── SettingsManager.kt
│   │   │   ├── ui/
│   │   │   │   ├── fragments/
│   │   │   │   │   ├── BaseFragment.kt
│   │   │   │   │   ├── HabitsFragment.kt
│   │   │   │   │   ├── MoodFragment.kt
│   │   │   │   │   ├── HydrationFragment.kt
│   │   │   │   │   └── SettingsFragment.kt
│   │   │   │   ├── adapters/
│   │   │   │   └── theme/
│   │   │   │       └── Color.kt
│   │   │   ├── utils/
│   │   │   │   ├── WindowSizeUtils.kt
│   │   │   │   ├── MotionUtils.kt
│   │   │   │   ├── AccessibilityUtils.kt
│   │   │   │   ├── StateManager.kt
│   │   │   │   └── BottomSheetUtils.kt
│   │   │   └── MainActivity.kt
│   │   └── res/
│   │       ├── navigation/
│   │       │   └── nav_graph.xml
│   │       ├── layout/
│   │       ├── values/
│   │       └── ...
│   └── assets/
│       ├── modernization_summary.md
│       └── README.md
```

## Key Components

### Navigation
- **Navigation Graph**: `res/navigation/nav_graph.xml`
- **MainActivity**: Single activity hosting all fragments
- **Adaptive Navigation**: Bottom Navigation for all screen sizes

### Themes & Styling
- **Material 3 Themes**: `res/values/themes.xml`
- **Color Definitions**: `ui/theme/Color.kt` and `res/values/colors.xml`
- **Dimensions**: `res/values/dimens.xml`

### Data Management
- **SharedPreferencesManager**: Legacy data manager
- **SettingsManager**: Modern SharedPreferences wrapper

### Utility Classes
- **WindowSizeUtils**: Adaptive layout handling
- **MotionUtils**: Animation and transition management
- **AccessibilityUtils**: Accessibility feature implementation
- **StateManager**: UI state management
- **BottomSheetUtils**: Bottom sheet functionality

## Modernization Features

### 1. Single-Activity Architecture
- Migrated from multiple Activities to single Activity with Fragments
- Implemented Navigation Component for fragment management
- Added proper back-stack handling

### 2. Material 3 Implementation
- Updated all UI components to Material 3 specifications
- Implemented proper theming with color, typography, and shape systems
- Added elevation handling for Material surfaces

### 3. Simplified Navigation
- Implemented consistent Bottom Navigation for all screen sizes
- Removed Navigation Rail for tablets/foldables for simplified UX

### 4. Edge-to-Edge Support
- Proper handling of system UI insets
- Transparent status and navigation bars
- Content that extends to screen edges

### 5. Accessibility
- Ensured minimum touch target sizes (48dp)
- Proper contrast ratios for text and UI elements
- Logical focus order for keyboard navigation
- Screen reader support

## Dependencies
- AndroidX Navigation Component
- AndroidX Window library
- Material Components for Android
- MPAndroidChart for data visualization
- Gson for JSON serialization

## Build Information
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 36 (Android 15)
- **Kotlin**: 1.9+
- **Gradle**: 8.0+

## Getting Started
1. Clone the repository
2. Open in Android Studio
3. Sync project with Gradle files
4. Run the application

## Contributing
This project demonstrates modern Android development practices. Feel free to:
1. Review the implementation
2. Suggest improvements
3. Extend functionality
4. Add tests

## License
This project is for educational purposes and demonstrates Android app modernization techniques.